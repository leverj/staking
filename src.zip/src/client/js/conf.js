export default {
  network: 'https://ropsten.infura.io',
  stake: '0x5e24f0bc04240630ee3752e4f577f77230939e7a',
  fee: '0x9b49c2111ff96c6e9b01b18118ee064381ca9a85',
  lev:'0xa26fe93339345c40dd1904a700c15d02352c2b0b'
}
